name="Vamshi"
echo $name

