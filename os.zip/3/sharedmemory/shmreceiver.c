#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>

int main()
{
	key_t key;
	key = ftok("f6",98);
	int shmid = shmget(key, 1024,0666);
	char *data = (char*)shmat(shmid,NULL,0);
	printf("Message received: %s\n",data);
	shmdt(data);
	shmctl(shmid,IPC_RMID,0);
	return 0;
}
