#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<string.h>

int main()
{
	key_t key;
	char *data;
	char *msg = "Good Morning CMR";
	key = ftok("f6",98);
	int shmid;
	shmid = shmget(key,1024,0666|IPC_CREAT);
	data = (char*)shmat(shmid,NULL,0);
	strcpy(data, msg);
	printf("Message written to shared memory\n");
	shmdt(data);
	return 0;
}
