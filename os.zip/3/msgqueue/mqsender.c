#include <stdio.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <string.h>

#define SIZE 100

struct msgbuf
{
	long mtype;
	char mtext[SIZE];
};

int main()
{
	key_t key;
	int mid;
	char *msg ="Hi CMR";
	struct msgbuf mb;
	mb.mtype = 12;
	strcpy(mb.mtext,msg);
	key = ftok("myfile",20);
	mid = msgget(key,0666|IPC_CREAT);
	msgsnd(mid,&mb,sizeof(mb.mtext),0);
	printf("Message sent");
}




