#include <stdio.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/msg.h>

#define MAX 100

struct msgbuf
{
	long mtype;
	char mtext[MAX];
};

int main()
{
	int mid;
	key_t key;
	key = ftok("myfile",20);
	struct msgbuf mb;
	mid = msgget(key,0666);
	msgrcv(mid,&mb,sizeof(mb.mtext),12,0);
	printf("I have received '%s' from message queue and it's type is %ld",mb.mtext,mb.mtype);
	msgctl(mid,IPC_RMID,0);
	return 0;
}






