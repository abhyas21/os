#Positional args
# $# no. of cmd line args
# $0 indicates script
# $1 to $9 indicates 1 to 9 cmd line args
# $@ individual strings in cmd line args
# $* single str representing all cmd line args

echo "No. of cmd line arguments = $#"
echo "the 1st cmd line argument is $1"
echo "the 2nd cmd line argument is $2"
echo "the 3rd cmd line argument is $3"
echo "the 4th cmd line argument is $4"
echo "the 5th cmd line argument is $5"
echo "the 6th cmd line argument is $6"
echo "the 7th cmd line argument is $7"
echo "the script name is $0"
echo "the entire cmd line argument is $*"
echo "the individual cmd line arguments are "
for var in "$@"
do
	echo $var
done






