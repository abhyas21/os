echo "Enter file name: "
read file
if [ -e $file ]
then
	echo "$file exists"
	if [ -r $file ]
	then
		echo "$file has read permission"
	elif [ -w $file ]
	then
		echo "$file has write permission"
	elif [ -x $file ]
	then
		echo "$file has execute permission"
	else
		echo "$file has no permisions"
	fi
fi
