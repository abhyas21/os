echo "Enter the multiplication table no: "
read n
i=1
echo "The multiplication table of $n is:"
while [ $i -le 10 ]
do
	echo "$n x $i = $(($n*$i))"
	i=$(($i+1))
done

