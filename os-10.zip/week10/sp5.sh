#Display first 10 natural no.s using while

n=1

while [ $n -le 10 ]
do
	echo "$n"
	n=$(($n+1))
done

