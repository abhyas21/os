for var in "$@"
do
   if [ -f $var ]
   then
     echo "$var is a regular file, no. of lines in $var is $(wc -l<"$var")"
   elif [ -d $var ]
     then
	  echo "$var is a directory file"
   else
      echo "Unknown file"
   fi
done


