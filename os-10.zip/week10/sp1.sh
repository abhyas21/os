# simple calculator program
echo "Enter 1st no: "
read a
echo "Enter 2nd no: "
read b
echo "The sum of $a and $b is $((a+b))"
echo "The product of $a and $b is $((a*b))"
echo "The difference of $a and $b is $((a-b))"
echo "The quotient of $a and $b is $((a/b))"
echo "The remainder of $a and $b is $((a%b))"
