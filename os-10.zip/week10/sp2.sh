#Relational
-eq --> n1=n2
-ne --> n1!=n2
-gt --> n1>n2
-lt --> n1<n2
-ge --> n1>=n2
-le --> n1<=n2

#String
S1=S2
S1!=S2
-z S (TRUE if NULL string)
-n S (TRUE if S is non-empty string)

#file test operators
-f file --> TRUE if file is a regular file (text file)
-d file --> TRUE if file is a directory file
-r file --> TRUE if file has read permission to the user
-w file --> TRUE if file has write permission to the user
-x file --> TRUE is file has executable permission to the user
-e file --> TRUE if file exists

#Logical 
e1 -a e2 -->TRUE if e1 and e2 are TRUE 
e1 -o e2 -->TRUE if e1 or e2 or both are TRUE
!exp --> TRUE if exp is FALSE

#Conditional
1) Simple IF
2) if-else
3) if-elif-else

#Simple if
if [ condition ]
then
	c1
	c2
fi

#if-else
if [ condition ]
then
	c1
	c2
else
	c3
fi

#if-elif-else
if [ condition1 ]
then
	c1
	c2
elif [ condition2 ]
	c3
	c4
else
	c5
fi

#Iterative statements
# 1) while
# 2) for
# 3) until

while [ condition ]
do
	c1
	c2
	...
done

for var in list
do
	c1
	c2
	...
done

until [ condition ]
do
	c1
	c2
	...
done


























