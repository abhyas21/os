echo "Enter file name: "
read file
if [ -f $file ]
then
	echo "$file is a regular file"
elif [ -d $file ]
then
	echo "$file is a directory file"
else
	echo "$file type is unknown"
fi
